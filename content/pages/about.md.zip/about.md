+++
title = "About"
author = ["Liam Hinzman"]
date = 2019-07-17
draft = false
noauthor = true
nocomment = true
nodate = true
nopaging = true
noread = true
+++

Hi, I'm Liam, a 17 y/o who’s trying to understand the world and myself.

**What I Do**

-   Machine learning research intern at Layer 6
-   Machine learning developer intern at SickKids
-   Learning full stack web development (MERN)
-   Playing piano
-   Occasionally I write here
